create function category(_stream_name character varying) returns character varying
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN
  return split_part(_stream_name, '-', 1);
END;
$$;
