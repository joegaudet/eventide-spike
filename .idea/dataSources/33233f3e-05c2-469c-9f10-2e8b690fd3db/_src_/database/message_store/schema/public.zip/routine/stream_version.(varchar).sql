create function stream_version(_stream_name character varying) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
  stream_version bigint;
BEGIN
  select max(position) into stream_version from messages where stream_name = _stream_name;

  return stream_version;
END;
$$;
